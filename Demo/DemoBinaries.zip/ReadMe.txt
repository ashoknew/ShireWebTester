ShreWebTester 1.0

This package contains the ShreWebTester binaries. 

To execute, run "ShireWebTestRunner.exe".  'YahooXMLtest.xml' test script shall be 
executed by software and create screen shot in the same location.

Send feedback to mashok.sai@gmail.com.

